# Apostille research for lunadreyer.com.au

Research date: 17 September 2026. Every fact is followed by its source. Items marked UNVERIFIED could not be confirmed on a primary (government or HCCH) source during this session. Several DFAT and Smartraveller pages (including "Notarial services in Australia" and the March 2026 Document Legalisation Request Form) refused automated fetching, so some in-Australia process details rely on secondary sources and are flagged.

---

## 1. What an apostille is

- The Apostille Convention is the HCCH "Convention of 5 October 1961 Abolishing the Requirement of Legalisation for Foreign Public Documents". Source: https://www.hcch.net/en/instruments/conventions/full-text/?cid=41
- It applies to "public documents which have been executed in the territory of one Contracting State and which have to be produced in the territory of another Contracting State" (Art. 1). Source: https://www.hcch.net/en/instruments/conventions/full-text/?cid=41
- Public documents include court documents, administrative documents, notarial acts, and official certificates placed on privately signed documents (Art. 1). Excluded: documents executed by diplomatic or consular agents, and administrative documents dealing directly with commercial or customs operations. Source: https://www.hcch.net/en/instruments/conventions/full-text/?cid=41
- The only formality a Contracting State may require is the Apostille certificate issued by the competent authority of the State the document comes from (Arts. 2 and 3). Source: https://www.hcch.net/en/instruments/conventions/full-text/?cid=41
- What it certifies (Art. 5): "the authenticity of the signature, the capacity in which the person signing the document has acted and, where appropriate, the identity of the seal or stamp which the document bears." Source: https://www.hcch.net/en/instruments/conventions/full-text/?cid=41
- What it does NOT certify: "An Apostille does not certify the content of the public document to which it relates." Source (HCCH, The ABCs of Apostilles): https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf
- An Apostille "may never be used for the recognition of a document in the country where that document was issued" (i.e. an Australian apostille is for use abroad only). Source: https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf
- If the document is to be used in a country where the Convention does not apply, HCCH says to contact that country's embassy or consulate. Source: https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf
- DFAT describes apostilles as certificates that certify "a signature, stamp or seal on an official Australian public document is genuine." Source: https://www.dfat.gov.au/about-us/our-services/apostilles-authentications-certificates-of-no-impediment-to-marriage/Pages/apostilles-authentications-and-certificates-of-no-impediment-to-marriage
- "The Department of Foreign Affairs and Trade (DFAT) is the only authority that can Apostille Australian public documents. Overseas, this service is provided by Australian embassies and consulates." Source: https://usa.embassy.gov.au/notarial-services-faqs
- DFAT issues an "Authentication" certificate (instead of an apostille) for documents going to countries that are not party to the Convention; that document then usually needs legalisation by the destination country's embassy or consulate. Source for the two certificate types: https://www.smartraveller.gov.au/consular-services/notarial-services/documents-overseas ; embassy step per HCCH: https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf
- An e-Apostille is "an official Apostille issued in digital form", and "an e-Apostille cannot be refused simply because it is issued in electronic form." Source: https://www.hcch.net/en/instruments/conventions/specialised-sections/apostille
- Australia entered the Convention into force on 16 March 1995. Source: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41

## 2. Why apostilles are needed

### Documents DFAT can legalise (Smartraveller list)
Source for all bullets in this subsection: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Birth certificates (including commemorative certificates and extracts).
- Marriage certificates (excluding ceremonial and commemorative certificates).
- Death certificates.
- Court documents, including Divorce Certificates.
- AFP National Police Checks or fingerprint reports.
- Australian citizenship certificates and International Movement Records.
- Degrees, awards, transcripts and other official documents from Australian universities; original TAFE documents; school documents only if verified by the state or territory education body or notarised.
- Private documents once notarised by an Australian Notary Public, e.g. "Power of Attorney, wills, bank statements, company documents".
- Chamber of commerce documents.
- Translations, which must show the translator's name and signature and the NAATI seal.

### Typical scenarios (editorial, supported by sources where noted)
- Buying property in Italy, including at judicial auction, through a representative holding a special power of attorney (procura speciale); foreign POAs need an apostille or legalisation plus an Italian translation. Sources: https://impatria.com/magazine/procura-acquisto-casa-asta-dall-estero/ (secondary, 11 March 2026) ; https://www.notaiodelmonte.it/la-forma-della-procura-estera/
- Italian citizenship by descent (iure sanguinis): applicants must submit "all original documents duly legalized and translated into Italian". Source: https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-straniero/cittadinanza/citizenship-by-descent-new-regulation/
- Marriage abroad (DFAT also issues Certificates of No Impediment to Marriage). Source: https://www.smartraveller.gov.au/consular-services/notarial-services/cni
- Working or studying overseas (degrees, transcripts, police checks), inheritance and estate matters (wills, death certificates, POAs), company matters overseas (company documents). Document types sourced from: https://www.smartraveller.gov.au/consular-services/notarial-services/documents . The pairing of scenario to document is general knowledge, not a quoted government statement.
- DFAT notes that the receiving overseas authority decides what is required and "In many cases, you won't need our services." Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents-overseas

### Italy citizenship by descent: 2025 changes (context for this audience)
- Law No. 74 of 23 May 2025 changed transmission rules; applicants born abroad must meet conditions such as having "a parent or a grandparent who, at the time of the applicant's birth ... held exclusively Italian citizenship". Source: https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-straniero/cittadinanza/citizenship-by-descent-new-regulation/
- Italian Constitutional Court judgment no. 63/2026 (decided 11 March 2026, deposited 30 April 2026) found the challenges to the new Art. 3-bis of Law 91/1992 (introduced by DL 36/2025, converted by Law 74/2025) not well founded, keeping the 27 March 2025 cut-off. Source: https://www.cortecostituzionale.it/scheda-pronuncia/2026/63 (summary obtained through an automated reader; have a lawyer confirm before publishing detail).

## 3. How to get an apostille in Australia (2026)

### Who and where
- DFAT delivers the service "through Australian Passport Offices in each state and territory." Source: https://www.smartraveller.gov.au/consular-services/notarial-services
- DFAT: "Australian Passport Offices in capital cities". Source: https://www.dfat.gov.au/about-us/our-services/apostilles-authentications-certificates-of-no-impediment-to-marriage/Pages/apostilles-authentications-and-certificates-of-no-impediment-to-marriage
- Enquiries email: legalisations.australia@dfat.gov.au. Source: https://www.smartraveller.gov.au/consular-services/notarial-services
- Cities (Sydney, Melbourne, Brisbane, Perth, Adelaide, Canberra, Hobart, Darwin): secondary source only. https://translayte.com/blog/how-do-i-get-an-apostille-in-australia (UNVERIFIED on a primary page, but consistent with "each state and territory").
- Melbourne office address given by a notary as "Australian Passport Office, Ground Floor, Collins Place, (enter via Exhibition Street), Melbourne VIC 3000", 8:30 am to 4:00 pm weekdays. Source: https://www.notarypublicmelbourne.com/dfat-apostille-service/ (UNVERIFIED on DFAT site).

### How to apply
- Two lodgement routes in Australia: an in-person appointment booked online through Smartraveller, or by post, using the Document Legalisation Request Form. Sources: https://www.notarypublicmelbourne.com/dfat-apostille-service/ ; https://www.swiftauthentication.com.au/guides/how-do-i-get-an-apostille-certificate-in-australia-dfat (secondary; the official page https://www.smartraveller.gov.au/consular-services/notarial-services/documents-in-australia could not be fetched, so treat details as UNVERIFIED).
- Current form: "Document Legalisation Request Form" dated March 2026 (form DLRF 1225), hosted at https://www.smartraveller.gov.au/sites/default/files/2026-03/Document_Legalisation_Request_Form_Mar_2026_0.pdf (title and URL confirmed through search; contents not fetched).
- Postal addresses reported as GPO Box 2239, Melbourne VIC 3001 or Sydney NSW 2001: UNVERIFIED (secondary source only: https://translayte.com/blog/how-do-i-get-an-apostille-in-australia). Do not publish without checking the current form.

### Fee
- A$105 per apostille and A$105 per authentication, effective 1 January 2026; Certificate of No Impediment to Marriage A$181. "Fees are adjusted annually in line with the Consumer Price Index (CPI) on 1 January each year." Source (Australian Embassy, The Hague, DFAT form effective 1 January 2026): https://netherlands.embassy.gov.au/files/thag/Document-Legalisation-Request-Form-2026_0.pdf
- Corroboration: Swift Apostille lists "DFAT: $105 per document". Source: https://www.swiftapostille.com.au/pricing
- Previous fee (2025): $102. Sources: https://www.notarypublicmelbourne.com/dfat-apostille-service/ ; https://www.swiftauthentication.com.au/guides/how-much-does-a-dfat-authentication-certificate-cost-in-australia-legalisation
- Discrepancy to note: the Smartraveller "documents overseas" page still showed "$92" per apostille or authentication when fetched. This looks out of date or specific to overseas missions; the 2026 DFAT form (A$105) is the better figure for lodgement in Australia. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents-overseas
- Notary fees are charged separately by the notary public and are not set by DFAT (general knowledge; amounts vary).

### Processing times
- No official DFAT processing time was retrievable from a primary page. UNVERIFIED.
- Secondary sources (2025): about 3 business days once lodged; in-person appointment waits reported as about 3 weeks (Melbourne, Brisbane) and 4 to 6 weeks (Sydney); postal route takes longer. Sources: https://www.swiftauthentication.com.au/guides/how-do-i-get-an-apostille-certificate-in-australia-dfat ; https://translayte.com/blog/how-do-i-get-an-apostille-in-australia
- Swift Apostille (2026 page) quotes 2 to 4 business days. Source: https://www.swiftapostille.com.au/pricing
- Overseas reference points: Australian Embassy Germany says apostilles "will normally be issued within 1-2 business days once received" (https://germany.embassy.gov.au/beln/apostilles.html); Australian missions in the USA aim for "7-10 business days of receipt" by mail (https://usa.embassy.gov.au/notarial-services-faqs).
- Suggested wording for the page: "DFAT's processing time is usually a few business days, but appointment availability varies by city and can add several weeks, so plan ahead."

### Does a private document need a notary first?
- Yes. Private documents qualify only "once they are notarised by an Australian Notary Public" (examples include Power of Attorney, wills, bank statements, company documents). Copies must also be notarised by an Australian Notary Public. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- The 2026 form states private documents must be "notarised by an Australian Notary Public before lodgement". Source: https://netherlands.embassy.gov.au/files/thag/Document-Legalisation-Request-Form-2026_0.pdf
- Original public documents (birth, marriage, death certificates, court documents, AFP checks, university documents) can generally be apostilled directly without notarisation. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- State notary lists are linked from Smartraveller. Source: https://www.smartraveller.gov.au/consular-services/notarial-services

### Electronic apostilles (e-Apostille)
- As of this research, DFAT does not issue e-Apostilles. The Australian Embassy in Germany states "DFAT cannot issue digital apostilles"; for electronic originals, "DFAT can only issue an Authentication or Apostille certificate on a copy we have printed ourselves directly from the source." Source: https://germany.embassy.gov.au/beln/apostilles.html
- The HCCH e-APP implementation chart lists Australia with an e-Register only (not e-Apostille issuance): "Only Apostilles issued on or after 14 December 2015 can be verified on the e-Register." Source: https://assets.hcch.net/docs/e8e7549d-e34a-452f-9fa3-cf2241aa4197.pdf
- Australia launched its e-Register on 14 December 2015. Source: https://www.hcch.net/en/news-archive/details/?varevent=454
- Apostilles issued after 14 December 2015 can be verified online; earlier ones through an embassy or the Australian Passport Office. Source: https://www.smartraveller.gov.au/consular-services/notarial-services
- Scanned copies of electronic documents are not accepted; the mission must access and print the document itself. Source: https://usa.embassy.gov.au/notarial-services-faqs
- Some university documents can be sent to DFAT digitally through My eQuals: secondary only, UNVERIFIED. Source: https://translayte.com/blog/how-do-i-get-an-apostille-in-australia

## 4. Which countries accept apostilles

### Headline numbers
- HCCH status table: "Number of Contracting Parties to this Convention: 130", "Last update: 30-VI-2026". Source: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41
- The 130th was Thailand: "With the accession of Thailand, the 1961 Apostille Convention now has 130 Contracting Parties." Source: https://www.hcch.net/en/news-archive/details/?varevent=1158
- Thailand acceded 30 June 2026; the Convention enters into force for Thailand on 28 February 2027. Until then Thailand still requires legalisation. Source: https://www.hcch.net/en/news-archive/details/?varevent=1158
- Viet Nam acceded 31 December 2025 (129th party); in force for Viet Nam from 11 September 2026. Source: https://www.hcch.net/en/news-archive/details/?varevent=1132
- Algeria acceded 5 November 2025; in force 9 July 2026. Source: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41
- So, as at 17 September 2026: 130 Contracting Parties, of which 129 have the Convention in force (Thailand pending). Derived from the two HCCH sources above.
- Some accessions carry objections from individual existing parties (marked on the status table), which means the Convention may not apply between those particular pairs of countries. Check the table for the specific pair. Source: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41

### Representative list with entry into force dates
Source for every date below: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41

Europe
- Italy: 11 February 1978
- Germany: 13 February 1966
- Spain: 25 September 1978
- Portugal: 4 February 1969
- France: 24 January 1965
- United Kingdom: 24 January 1965
- Ireland: 9 March 1999
- Greece: 18 May 1985
- Croatia: 8 October 1991
- Malta: 3 March 1968
- Switzerland: 11 March 1973
- Netherlands: 8 October 1965
- Türkiye: 29 September 1985

Americas
- United States: 15 October 1981
- Canada: 11 January 2024
- Mexico: 14 August 1995
- Brazil: 14 August 2016
- Argentina: 18 February 1988
- Chile: 30 August 2016

Asia Pacific
- Australia: 16 March 1995
- New Zealand: 22 November 2001
- Japan: 27 July 1970
- Republic of Korea: 14 July 2007
- China (People's Republic of): 7 November 2023
- India: 14 July 2005
- Singapore: 16 September 2021
- Indonesia: 4 June 2022
- Philippines: 14 May 2019
- Pakistan: 9 March 2023
- Bangladesh: 30 March 2025
- Viet Nam: 11 September 2026
- Thailand: acceded, in force from 28 February 2027
- Fiji: 10 October 1970
- Samoa: 13 September 1999
- Tonga: 4 June 1970
- Vanuatu: 30 July 1980
- Hong Kong and Macao do not appear as separate rows on the table; the Convention has long applied to both through China's arrangements. UNVERIFIED on the status table page itself; confirm in the China entry notes before publishing.

Middle East and Africa
- Israel: 14 August 1978
- Saudi Arabia: 7 December 2022
- Bahrain: 31 December 2013
- Oman: 30 January 2012
- South Africa: 30 April 1995
- Rwanda: 5 June 2024
- Algeria: 9 July 2026

### Notable countries NOT party (full legalisation through embassy or consulate still needed)
Checked against the HCCH status table on 17 September 2026; none of these appear as Contracting Parties. Source: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41
- United Arab Emirates
- Qatar
- Kuwait
- Egypt
- Jordan
- Lebanon
- Iraq
- Iran
- Malaysia
- Myanmar
- Cambodia
- Laos
- Sri Lanka
- Nepal
- Papua New Guinea
- Nigeria
- Kenya
- Ethiopia
- Taiwan
- Thailand (party, but not in force until 28 February 2027)
- Viet Nam is no longer on this list: the Convention has applied there since 11 September 2026.
- For these, DFAT issues an Authentication certificate, then the destination country's embassy or consulate legalises it. HCCH guidance: https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf ; DFAT certificate types: https://www.smartraveller.gov.au/consular-services/notarial-services/documents-overseas . The exact embassy procedure for each country is UNVERIFIED and varies.

## 5. Italy specifics

### Apostille and translation for Australian documents used in Italy
- Italy is a party (in force 11 February 1978), so Australian public documents need a DFAT apostille, not Italian consular legalisation. Sources: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41 ; https://www.esteri.it/en/servizi-opportunita/italiani-all-estero/traduzione-e-legalizzazione-documenti/
- Italian Foreign Ministry: foreign documents must be translated into Italian (except multilingual standard forms) and the translation must be certified as conforming to the original ("per traduzione conforme"); Hague Convention countries can use the apostille instead of consular legalisation. Source: https://www.esteri.it/en/servizi-opportunita/italiani-all-estero/traduzione-e-legalizzazione-documenti/
- Italian Consulate General Sydney lists three translation routes: (1) a sworn translator in Italy (lists available from Italian courts); (2) translations sworn before Italian courts or municipalities; (3) translation by certified translators with subsequent legalisation, i.e. an apostille from Foreign Affairs. It also keeps a list of translators known to the Consulate. Source: https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/traduzione-e-legalizzazione-dei-documenti/
- DFAT can apostille translations that bear the translator's name and signature and the NAATI seal. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Italian notaries (Triveneto committee guidance): the apostille itself does not need translating, because its format is standardised. Source: https://www.notaitriveneto.it/dettaglio-orientamenti-diritto-internazionale-234-procure-provenienti-dallestero---modalita-di-traduzione.html
- A foreign POA used for an Italian deed needs an apostille (Hague countries) or Italian consular legalisation (other countries), and "occorre, anzitutto, la traduzione in lingua italiana" (it must first be translated into Italian). Source (Notaio Edoardo Del Monte): https://www.notaiodelmonte.it/la-forma-della-procura-estera/
- The usual Australian route for an Italian POA: signed before an Australian Notary Public, apostilled by DFAT, then translated into Italian (sworn or certified translation). Individual steps sourced above; the combined sequence is standard practice. The Sydney Consulate confirms that foreign citizens can use local lawyers or notaries who draft in Italian and remain "responsible for obtaining apostille legalization". Source: https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/

### Consular POA (procura consolare) alternative
- Consular notarial services are for Italian citizens only (Legislative Decree 71/2011), with limited exceptions. Sources: https://consbrisbane.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/notary-service/ ; https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/
- Melbourne: the service is for "Italian citizens able to speak Italian"; foreigners are referred to Italian speaking lawyers. Source: https://consmelbourne.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/power-of-attorney/
- Sydney: by appointment only, via a request form; for a POA, send a draft in Word format prepared by the Italian notary or lawyer; "The Office cannot provide any legal assistance/advice." Sources: https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/ ; https://conssydney.esteri.it/it/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/procure/
- General POA ("procura generale") covers all affairs, indefinitely; special POA ("procura speciale") covers specific affairs and ends when they are completed; uses include buying and selling. Source: https://conssydney.esteri.it/it/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/procure/
- Consular fees, Melbourne, 1 July to 30 September 2026: general POA or revocation A$147.30; special POA or revocation A$98.20. Source: https://consmelbourne.esteri.it/en/chi-siamo/la-sede/consular-fees/
- Sydney publishes fee tables effective from 1 April 2026 (PDFs, amounts not extracted). Source: https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/consular-fees/
- Brisbane contact: notarile.brisbane@esteri.it, +61 7 3229 8944. Source: https://consbrisbane.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/notary-service/
- Typical consular appointment waiting times: UNVERIFIED (no consulate page states them).
- A consular POA is issued by an Italian authority, so it needs no apostille and is already in Italian. Source for "comes from the Italian consul": https://www.notaiodelmonte.it/la-forma-della-procura-estera/ ; the "already in Italian, no translation" point follows from the Triveneto guidance on consular documents: https://www.notaitriveneto.it/dettaglio-orientamenti-diritto-internazionale-234-procure-provenienti-dallestero---modalita-di-traduzione.html

### Judicial auctions (aste giudiziarie) and the procura speciale
- Art. 571 c.p.c.: anyone except the debtor may offer to buy the seized property "personalmente o a mezzo di procuratore legale" (in person or through a lawyer); the deposit (cauzione) must be "non inferiore al decimo" (at least 10%) of the price offered. Source: https://www.brocardi.it/codice-di-procedura-civile/libro-terzo/titolo-ii/capo-iv/sezione-iii/art571.html
- Art. 579 c.p.c.: bids must be made "personalmente o a mezzo di mandatario munito di procura speciale" (in person or through an agent with a special power of attorney); "I procuratori legali possono fare offerte per persone da nominare" (lawyers may bid for a person to be named). Source: https://www.brocardi.it/codice-di-procedura-civile/libro-terzo/titolo-ii/capo-iv/sezione-iii/art579.html
- Art. 583 c.p.c.: a lawyer who wins "for a person to be named" must declare that person's name at the court registry within three days of the auction and deposit the power of attorney; otherwise the award becomes final in the lawyer's own name. Source: https://www.brocardi.it/codice-di-procedura-civile/libro-terzo/titolo-ii/capo-iv/sezione-iii/art583.html
- Practical guidance (secondary, 11 March 2026): the procura should be in writing, preferably notarial, prepared before the bid; foreign procure need an apostille or legalisation and "una traduzione giurata in italiano" (a sworn Italian translation); "una procura mal redatta ... può rendere inefficace l'offerta" (a badly drafted POA can make the offer ineffective). Source: https://impatria.com/magazine/procura-acquisto-casa-asta-dall-estero/
- Portale delle Vendite Pubbliche: "un sito web istituito dal Ministero della Giustizia" where all judicial sales are published under art. 490 c.p.c.; publication mandatory from 19 February 2018 and online (telematic) sales mandatory from 10 April 2018. URL: https://pvp.giustizia.it/pvp/it/ . Source: https://tribunale-avezzano.giustizia.it/resources/cms/documents/COMUNICATO_PVP.pdf
- Balance payment deadline (commonly up to 120 days): UNVERIFIED; set by each sale notice (avviso di vendita).

## 6. Common mistakes that delay apostilles

- Private document not notarised first (e.g. a POA signed only before a JP or witness). Private documents must be notarised by an Australian Notary Public. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Sending a plain photocopy or a JP certified copy: copies must be notarised by an Australian Notary Public. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents . (The specific "JP copies rejected" wording is an inference from this rule.)
- Laminated, framed or altered documents: "Public documents that have been laminated, framed or altered in any way are not acceptable." Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Damaged originals: documents must be undamaged, unaltered and unlaminated. Source: https://germany.embassy.gov.au/beln/apostilles.html
- Ceremonial or commemorative marriage certificates (the registry certificate is needed). Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Foreign education documents cannot be legalised by DFAT, "Even if notarised by an Australian Notary Public". Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- School documents signed only by the school administration. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Notarised copies of university documents where the notary has not stated that "the original record has been verified with the issuing institution". Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Translations without the translator's name, signature and NAATI seal. Source: https://www.smartraveller.gov.au/consular-services/notarial-services/documents
- Printing an electronic document (e.g. a digital AFP check) yourself or sending a scan: DFAT must print it from the source. Sources: https://germany.embassy.gov.au/beln/apostilles.html ; https://usa.embassy.gov.au/notarial-services-faqs
- Separating pages later: DFAT may bind multi-page documents, and once bound they "cannot be separated". Source: https://netherlands.embassy.gov.au/files/thag/Document-Legalisation-Request-Form-2026_0.pdf
- Getting an apostille when the destination is not a Convention party (or not yet in force, e.g. Thailand before 28 February 2027): an Authentication plus embassy legalisation is needed instead. Source: https://www.hcch.net/en/instruments/conventions/status-table/?cid=41
- Wrong order of steps for Italy: translating before notarising and apostilling, or leaving the translation uncertified. The Italian rule needs a certified conforming translation. Source: https://www.esteri.it/en/servizi-opportunita/italiani-all-estero/traduzione-e-legalizzazione-documenti/
- Poorly drafted auction POA (bidder not clearly identified, no specific authority to bid): can make the offer inadmissible. Source: https://impatria.com/magazine/procura-acquisto-casa-asta-dall-estero/
- Leaving too little time: appointment waits can run to weeks in some cities (secondary, UNVERIFIED). Source: https://translayte.com/blog/how-do-i-get-an-apostille-in-australia
- Signatory not recognised by DFAT (e.g. a document signed by an official whose signature DFAT cannot verify): UNVERIFIED as a published DFAT rejection reason. DFAT checks that the signature, seal or stamp is genuine. Source for the check: https://germany.embassy.gov.au/beln/apostilles.html

---

## Recommended authoritative outbound links

- https://www.smartraveller.gov.au/consular-services/notarial-services : DFAT Smartraveller hub for notarial services, apostilles and notary lists by state.
- https://www.smartraveller.gov.au/consular-services/notarial-services/documents : DFAT list of documents it can and cannot legalise.
- https://www.smartraveller.gov.au/consular-services/notarial-services/documents-in-australia : DFAT page on how to request apostilles in Australia (booking and post).
- https://www.dfat.gov.au/about-us/our-services/apostilles-authentications-certificates-of-no-impediment-to-marriage/Pages/apostilles-authentications-and-certificates-of-no-impediment-to-marriage : DFAT overview of apostilles, authentications and CNIs.
- https://orao.dfat.gov.au/pages/verifyapostille.aspx : DFAT e-Register to verify Australian apostilles issued since 14 December 2015.
- https://www.ag.gov.au/international-relations/private-international-law/apostilles : Attorney-General's Department page on apostilles (not fetched in this session).
- https://www.hcch.net/en/instruments/conventions/full-text/?cid=41 : Full text of the 1961 Apostille Convention.
- https://www.hcch.net/en/instruments/conventions/status-table/?cid=41 : Official HCCH list of Contracting Parties and entry into force dates.
- https://www.hcch.net/en/instruments/conventions/specialised-sections/apostille : HCCH Apostille Section, including the e-APP (e-Apostille and e-Register).
- https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf : HCCH "The ABCs of Apostilles" plain language brochure.
- https://www.esteri.it/en/servizi-opportunita/italiani-all-estero/traduzione-e-legalizzazione-documenti/ : Italian Foreign Ministry rules on translation and legalisation of foreign documents.
- https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/traduzione-e-legalizzazione-dei-documenti/ : Italian Consulate General Sydney, translation and legalisation.
- https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/ : Italian Consulate General Sydney, notarial services including POAs.
- https://consmelbourne.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/power-of-attorney/ : Italian Consulate General Melbourne, power of attorney.
- https://consmelbourne.esteri.it/en/chi-siamo/la-sede/consular-fees/ : Italian Consulate General Melbourne, current consular fees.
- https://pvp.giustizia.it/pvp/it/ : Portale delle Vendite Pubbliche, Italian Ministry of Justice portal for judicial sales.
