# Apostille in Australia: final page content for lunadreyer.com.au

Prepared 17 September 2026. Everything below the "Page copy" heading is ready to paste into the page builder. Items in square brackets such as [PHONE] and [IMAGE: ...] are placeholders or placement markers, not visible copy.

---

## 1. SEO head

| Field | Value |
|---|---|
| Title tag (54 characters) | Apostille in Australia: DFAT Guide, Cost and Italy POA |
| Meta description (154 characters) | How to get an apostille in Australia: DFAT steps, the A$105 fee, and apostilled powers of attorney for Italy, Spain, Germany and other European countries. |
| URL slug | /apostille-australia |
| Canonical URL | https://lunadreyer.com.au/apostille-australia |
| Primary keyword | apostille Australia |
| Open Graph title | Apostille in Australia for Europe (2026 Guide) |
| Open Graph description | The DFAT fee, the step by step process, the 130 Convention countries, and apostilled powers of attorney for Italy, Spain, Germany and beyond. |
| Open Graph image | https://lunadreyer.com.au/media/apostille-certificate-navy-folder-desk.jpg |
| Open Graph type | article |

**Secondary keywords (12)**

1. how to get an apostille in Australia
2. DFAT apostille
3. apostille cost Australia
4. apostille power of attorney Italy
5. which countries accept apostille
6. apostille vs authentication
7. Hague Apostille Convention countries
8. notarise documents for apostille
9. verify Australian apostille
10. procura speciale from Australia
11. apostille for Italian citizenship documents
12. power of attorney for Italian property auction
13. apostille power of attorney Spain
14. apostille power of attorney Germany

---

## 2. Page copy

# Apostille in Australia: How to Get One, What It Costs and How It Works for Italy

[IMAGE: hero, apostille-certificate-navy-folder-desk.jpg]

If you need an apostille in Australia, you are probably preparing to use an Australian document overseas: to buy property, apply for citizenship, marry, study, work or manage an inheritance. An apostille is the certificate the Department of Foreign Affairs and Trade (DFAT) places on an Australian public document so it is accepted in countries that belong to the Hague Apostille Convention. This guide explains what an apostille is, how to get one step by step, what it costs in 2026, which countries accept it, and how it fits into a power of attorney for Italy.

I am Luna Dreyer, a translator with a BA in Translation Studies from the University of Heidelberg, working in German, English, Spanish, Italian and Portuguese. I help Australians prepare [powers of attorney for Italy](/power-of-attorney-italy) and plan the apostille around them, so nothing is left to chance.

> **Key facts at a glance**
>
> - **Who issues it:** DFAT, through Australian Passport Offices in each state and territory. Overseas, Australian embassies and consulates provide the service.
> - **DFAT fee:** A$105 per apostille from 1 January 2026, adjusted each 1 January in line with CPI.
> - **Member countries:** 130 Contracting Parties to the Apostille Convention (HCCH status table, updated 30 June 2026).
> - **Typical steps:** check the destination country, notarise private documents, lodge with DFAT, pay the fee, allow time, verify online.
> - **Italy:** a Convention member since 1978, so Australian documents need an apostille (not consular legalisation) plus an Italian translation.

## What is an apostille?

An apostille is a standard certificate created by the Hague Conference on Private International Law (HCCH) under the [Convention of 5 October 1961 Abolishing the Requirement of Legalisation for Foreign Public Documents](https://www.hcch.net/en/instruments/conventions/full-text/?cid=41). When a public document issued in one member country needs to be used in another member country, the apostille is the only formality that country may ask for. It replaces the older chain of embassy and consular stamps.

In Australia, DFAT is the only authority that can apostille Australian public documents. DFAT describes the service on its page on [apostilles, authentications and certificates of no impediment to marriage](https://www.dfat.gov.au/about-us/our-services/apostilles-authentications-certificates-of-no-impediment-to-marriage/Pages/apostilles-authentications-and-certificates-of-no-impediment-to-marriage) as confirming that a signature, stamp or seal on an official Australian public document is genuine. Australia has been a party to the Convention since 16 March 1995.

### What an apostille certifies

Under Article 5 of the Convention, an apostille certifies three things:

1. The authenticity of the signature on the document.
2. The capacity in which the person signing the document acted (for example, as a notary public or a registrar).
3. Where relevant, the identity of the seal or stamp on the document.

### What an apostille does not certify

- **The content.** As the HCCH explains in its plain language guide, [The ABCs of Apostilles](https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf), an apostille does not certify what the document says.
- **Use at home.** An apostille can never be used to recognise a document in the country that issued it. An Australian apostille is for use overseas only.
- **Translation or acceptance.** The receiving authority overseas decides what it needs. It may still ask for a translation, and DFAT itself notes that in many cases you will not need its services at all.

### What an Australian apostille looks like

[IMAGE: apostille-certificate-australia-dfat-example.jpg]

An Australian apostille follows the model certificate set out in the Convention. It has ten numbered fields, including the country, the name of the person who signed the document, the capacity in which they signed, the place and date of the apostille and its unique number, and it carries DFAT's seal and the signature of the issuing officer. At the time of writing, DFAT issues paper apostilles only, not digital e-Apostilles.

## Why you might need an apostille

### Documents DFAT can apostille

According to DFAT's list of [documents it can and cannot legalise](https://www.smartraveller.gov.au/consular-services/notarial-services/documents), these include:

- Birth certificates, including commemorative certificates and extracts
- Marriage certificates (not ceremonial or commemorative certificates)
- Death certificates
- Court documents, including divorce certificates
- AFP National Police Checks and fingerprint reports
- Australian citizenship certificates and International Movement Records
- Degrees, transcripts and other official documents from Australian universities, and original TAFE documents
- School documents, but only if verified by the state or territory education body or notarised
- Chamber of commerce documents
- Private documents such as a power of attorney, a will, bank statements or company documents, once notarised by an Australian Notary Public
- Translations that show the translator's name and signature and the NAATI seal

### Common life situations

- **Buying property in Italy**, including at a judicial auction, through a representative holding a special power of attorney (procura speciale).
- **Italian citizenship by descent.** The Italian Consulate General in Sydney asks for original documents duly legalised and translated into Italian. The rules changed in 2025, so check the current requirements before you order certificates.
- **Marrying overseas.** DFAT also issues Certificates of No Impediment to Marriage.
- **Working or studying overseas**, usually with degrees, transcripts or police checks.
- **Inheritance and estates**, often involving wills, death certificates and powers of attorney.
- **Company matters overseas**, involving notarised company documents.

## How to get an apostille in Australia: step by step

[VIDEO: apostille-certificate-desk-law-books.mp4]

### Step 1: Check what the destination country requires

Find out whether the Apostille Convention is in force in the country where the document will be used. If it is, you need an apostille. If it is not, you need an authentication followed by legalisation at that country's embassy or consulate. Ask the receiving authority whether it also needs a translation, and whether that translation must be apostilled too.

### Step 2: Have private documents notarised by an Australian Notary Public

Private documents, such as a power of attorney, a will, bank statements or company documents, can only be apostilled once they are notarised by an Australian Notary Public. Copies must be notarised too. Original public documents, such as birth, marriage and death certificates, court documents, AFP checks and university documents, can generally be lodged directly. DFAT's [notarial services hub on Smartraveller](https://www.smartraveller.gov.au/consular-services/notarial-services) links to notary lists for each state. Notary fees are set by the notary and are separate from the DFAT fee.

### Step 3: Lodge your documents with DFAT by appointment or by post

DFAT delivers the service through Australian Passport Offices in each state and territory. You can [book an in-person appointment or lodge by post](https://www.smartraveller.gov.au/consular-services/notarial-services/documents-in-australia) using the current Document Legalisation Request Form (the March 2026 version at the time of writing). Check the current form for the correct postal address before sending anything. Enquiries go to legalisations.australia@dfat.gov.au.

### Step 4: Pay the DFAT fee

From 1 January 2026, DFAT charges A$105 for each apostille, and the same for each authentication. Fees are adjusted in line with the Consumer Price Index on 1 January each year, so budget for one fee per certificate and check the amount if you are lodging early in a new year.

### Step 5: Allow enough time

DFAT's processing time is usually a few business days, but appointment availability varies by city and can add several weeks, so plan ahead. Lodging by post adds delivery time in both directions. If your document has several pages, DFAT may bind them, and bound pages cannot be separated afterwards.

### Step 6: Check and verify your apostille

When your document comes back, check that the details are correct. Apostilles issued on or after 14 December 2015 can be verified on [DFAT's apostille e-Register](https://orao.dfat.gov.au/pages/verifyapostille.aspx); older ones can be verified through an Australian embassy or the Australian Passport Office. The HCCH explains how electronic registers work in its [Apostille Section](https://www.hcch.net/en/instruments/conventions/specialised-sections/apostille).

## Apostille vs authentication

Both certificates are issued by DFAT, but they are used for different destinations. DFAT's page on [using Australian documents overseas](https://www.smartraveller.gov.au/consular-services/notarial-services/documents-overseas) explains the two types.

| | Apostille | Authentication |
|---|---|---|
| Used for | Countries where the Apostille Convention is in force | Countries that are not party to the Convention, or where it is not yet in force |
| Issued by | DFAT | DFAT |
| DFAT fee (2026) | A$105 | A$105 |
| What happens next | Nothing further on the legalisation side: the apostille is the only formality the destination may ask for | The document usually needs legalisation by the destination country's embassy or consulate |
| Examples | Italy, Germany, Spain, United Kingdom, United States, New Zealand | United Arab Emirates, Qatar, Egypt, Malaysia, and Thailand until 28 February 2027 |

## Which countries accept apostilles?

The [HCCH status table for the Apostille Convention](https://www.hcch.net/en/instruments/conventions/status-table/?cid=41) lists 130 Contracting Parties (last updated 30 June 2026). Thailand became the 130th party when it acceded on 30 June 2026, but the Convention only enters into force for Thailand on 28 February 2027. Viet Nam has applied the Convention since 11 September 2026, and Algeria since 9 July 2026.

One detail matters: some existing members have lodged objections to certain new accessions, which means the Convention may not apply between that particular pair of countries. Always check the status table for your destination.

### Selected member countries by region (year the Convention entered into force)

| Region | Countries |
|---|---|
| Europe | Italy (1978), Germany (1966), Spain (1978), Portugal (1969), France (1965), United Kingdom (1965), Ireland (1999), Greece (1985), Croatia (1991), Malta (1968), Switzerland (1973), Netherlands (1965), Türkiye (1985) |
| Americas | United States (1981), Canada (2024), Mexico (1995), Brazil (2016), Argentina (1988), Chile (2016) |
| Asia | Japan (1970), Republic of Korea (2007), China (2023), India (2005), Singapore (2021), Indonesia (2022), Philippines (2019), Pakistan (2023), Bangladesh (2025), Viet Nam (2026) |
| Pacific | Australia (1995), New Zealand (2001), Fiji (1970), Samoa (1999), Tonga (1970), Vanuatu (1980) |
| Middle East and Africa | Israel (1978), Saudi Arabia (2022), Bahrain (2013), Oman (2012), South Africa (1995), Rwanda (2024), Algeria (2026) |
| Joining soon | Thailand (in force from 28 February 2027) |

This is a selection, not the full list of 130.

### Countries that still need embassy legalisation

The following countries and places did not appear as Contracting Parties on the HCCH status table when checked on 17 September 2026:

- **Middle East:** United Arab Emirates, Qatar, Kuwait, Jordan, Lebanon, Iraq, Iran
- **Africa:** Egypt, Nigeria, Kenya, Ethiopia
- **Asia:** Malaysia, Myanmar, Cambodia, Laos, Sri Lanka, Nepal, Taiwan, and Thailand until 28 February 2027
- **Pacific:** Papua New Guinea

For these destinations, DFAT issues an authentication certificate, and the document is then legalised by that country's embassy or consulate. Each embassy sets its own procedure, so contact it directly before you lodge anything.

## Apostilles for Italy: powers of attorney, property and judicial auctions

Italy has applied the Apostille Convention since 11 February 1978, so Australian public documents need a DFAT apostille rather than Italian consular legalisation. The Italian Foreign Ministry's rules on the [translation and legalisation of foreign documents](https://www.esteri.it/en/servizi-opportunita/italiani-all-estero/traduzione-e-legalizzazione-documenti/) also require foreign documents to be translated into Italian (except multilingual standard forms), with the translation certified as conforming to the original.

### A power of attorney for buying property in Italy

Italian law distinguishes two main types of power of attorney:

- **Procura generale** (general power of attorney): covers all of your affairs, with no set end date.
- **Procura speciale** (special power of attorney): covers specific matters, such as buying or selling a property, and ends once those matters are completed.

For a property purchase, and especially for a judicial auction, a procura speciale with precise wording is what your Italian lawyer or notary will look for. The usual Australian route looks like this:

1. The power of attorney is drafted, with wording your Italian lawyer or notary can accept.
2. You sign it before an Australian Notary Public.
3. DFAT adds the apostille.
4. The document receives an Italian translation certified as conforming to the original. Italian notarial guidance notes that the apostille certificate itself does not need translating, because its format is standardised. Your Italian lawyer or notary will confirm exactly what must be translated.

The Italian Consulate General in Sydney notes on its [notarial services page](https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/) that foreign citizens can use local lawyers or notaries who draft in Italian, and that those professionals remain responsible for obtaining the apostille. Consular notarial services are mainly for Italian citizens: the Consulate General in Melbourne, for example, describes its [power of attorney service](https://consmelbourne.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/power-of-attorney/) as being for Italian citizens able to speak Italian. Whichever route you take, confirm with your Italian lawyer or notary what your document needs before you sign.

### Translation routes accepted for Italy

The Italian Consulate General in Sydney sets out three translation routes on its page about [translating and legalising documents](https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/traduzione-e-legalizzazione-dei-documenti/):

1. A sworn translation by a translator in Italy (Italian courts keep lists).
2. A translation sworn before an Italian court or municipality.
3. A translation by a certified translator, followed by legalisation (an apostille from Foreign Affairs).

Keep in mind that DFAT only apostilles translations that show the translator's name and signature and the NAATI seal.

### Italian judicial auctions (aste giudiziarie) in plain English

Every Italian judicial property sale is published on the [Portale delle Vendite Pubbliche](https://pvp.giustizia.it/pvp/it/), the public sales portal set up by Italy's Ministry of Justice. Publication there has been mandatory since 19 February 2018, and online sales since 10 April 2018. Three articles of the Italian Code of Civil Procedure (c.p.c.) explain why your paperwork matters:

- **Article 571 c.p.c.:** anyone except the debtor can make an offer, either in person or through a lawyer. The offer must come with a deposit (cauzione) of at least 10% of the price offered.
- **Article 579 c.p.c.:** bids are made in person or through an agent holding a special power of attorney (procura speciale). Lawyers may also bid for "a person to be named" (per persona da nominare).
- **Article 583 c.p.c.:** if a lawyer wins for a person to be named, they have three days after the auction to declare that person's name at the court registry and deposit the power of attorney. If they do not, the property is awarded to the lawyer personally.

In practice, this means your power of attorney must be drafted, signed, apostilled and translated before the auction date. A badly drafted power of attorney can make an offer ineffective. Each sale notice (avviso di vendita) sets its own conditions, including the deadline for paying the balance, so read it with your lawyer. You can read more in my guide to [buying property in Italy from Australia](/buying-property-in-italy).

## Common mistakes that delay an apostille

1. **Skipping the notary.** A power of attorney signed only before a Justice of the Peace or a witness is not enough. Private documents must be notarised by an Australian Notary Public.
2. **Sending plain or JP certified copies.** Copies must also be notarised by an Australian Notary Public.
3. **Laminated, framed, altered or damaged documents.** DFAT does not accept them.
4. **Ceremonial marriage certificates.** You need the certificate issued by the registry, not the ceremonial or commemorative one.
5. **Foreign education documents.** DFAT cannot legalise them, even if an Australian Notary Public has notarised them.
6. **School documents signed only by the school.** They must be verified by the state or territory education body or notarised.
7. **University copies without verification.** The notary must state that the original record has been verified with the issuing institution.
8. **Translations without a NAATI seal.** DFAT requires the translator's name, signature and NAATI seal.
9. **Printing or scanning electronic documents yourself.** For electronic originals, such as a digital police check, DFAT prints the document directly from the source.
10. **Separating bound pages.** Once DFAT binds a multi-page document, the pages cannot be separated.
11. **Choosing the wrong certificate.** If the destination is not a Convention party, or the Convention is not yet in force there (like Thailand before 28 February 2027), you need an authentication and embassy legalisation instead.
12. **The wrong order for Italy.** Translating before notarising and apostilling, or leaving the translation uncertified, can mean starting again.
13. **A vague auction power of attorney.** If the bidder is not clearly identified or the authority to bid is missing, the offer may be inadmissible.
14. **Leaving it too late.** Appointment availability varies by city and can add several weeks.

## My story: eleven weeks for one document

> "I do this so no one else loses months, or an opportunity, to paperwork."

When I needed a power of attorney for use in Italy, I thought I knew what I was doing. I am a translator, and legal documents are part of my daily work. I contacted the Italian consulate, prepared everything I was asked for, and waited.

It took five weeks.

When the document finally arrived, I felt relieved. Then I discovered something nobody had mentioned: the power of attorney still needed an apostille before it could be used in Italy, and that had to be arranged separately. Six more weeks.

Eleven weeks in total, for a single document.

What I remember most is not the paperwork itself. It is the waiting, and the uncertainty. Checking my inbox every morning. Not knowing whether I had done things in the right order, or whether another requirement was waiting around the corner. Plans in Italy that simply could not move until a piece of paper did.

Looking back, the delay came from the sequence. Each step was handled on its own, one after another, when several could have run side by side. With the right notary, the right wording from the start, and the apostille planned in from day one, the whole process could have been far faster.

That experience changed how I work. Today I help Australians prepare powers of attorney and apostilles for Italy. Many of them are buying property, some at Italian judicial auctions through a trusted avvocato who bids on their behalf. In that world, timing matters, because an auction date does not wait for paperwork.

So I map out every step before anything is signed. I draft the power of attorney in Italian, coordinate the notary and the apostille in the right order, and arrange the Italian translation, so my clients know exactly where they stand at each stage.

I do this so no one else loses months, or an opportunity, to paperwork.

## An apostille and a phone call away from Salerno

[VIDEO: apostille-certificate-salerno-lunch-table.mp4]

Picture an early morning on the lungomare. The Gulf of Salerno is calm and silver, the light is turning gold on the water, and your first espresso of the day is waiting at a café table beneath the palms.

Behind you, the centro storico wakes slowly. Narrow medieval lanes lead up to the Duomo, its colonnaded courtyard cool in the shade. Climb a little further and the Minerva garden opens in terraces above the rooftops, with the whole bay spread out below. In the afternoon, the ferry glides along the coast to Amalfi and Positano. By evening you are back for the passeggiata, the whole town strolling by the sea, with a small glass of limoncello to close the day.

Salerno is the gateway to the Amalfi Coast, and for many Australians it is where the dream of a home in Italy begins.

The first practical step is simpler than most people expect. One properly prepared power of attorney, with an apostille, allows a trusted Italian lawyer to act for you in Italy while you stay here in Australia. Every property and every purchase is different, and no outcome is guaranteed, but with your paperwork in order, you are ready when the right home appears.

If Salerno is calling, let's talk about your first step. Call me on [PHONE] or email [mail@lunadreyer.com.au](mailto:mail@lunadreyer.com.au).

## How I can help with your apostille and power of attorney for Italy

[IMAGE: translator-reviewing-apostilled-document.jpg]

I plan the whole process with you from day one, so steps that can run side by side do, and you always know what comes next.

- **Drafting your power of attorney in Italian**, as a procura speciale or procura generale, with wording prepared for your Italian lawyer or notary.
- **Coordinating the Australian Notary Public and the DFAT apostille** in the right order, so nothing has to be redone.
- **Arranging the Italian translation** through a route accepted in Italy.
- **Introductions to trusted Italian lawyers (avvocati)**, including lawyers who can bid for you at a judicial auction.
- **Clear communication in five languages:** German, English, Spanish, Italian and Portuguese. See my other [translation services](/translation-services).

To be clear about roles: I am a translator, not a lawyer or a notary, and I do not give legal advice. The apostille itself is issued by DFAT, and legal advice in Italy comes from your avvocato.

**Ready to start?** Email [mail@lunadreyer.com.au](mailto:mail@lunadreyer.com.au), call [PHONE], or send me a message through the [contact page](/contact). Tell me which document you need, where it will be used and your deadline, and I will map out the steps for you.

## Frequently asked questions about apostilles in Australia

### How much does an apostille cost in Australia?

From 1 January 2026, DFAT charges A$105 for each apostille, and the same for an authentication certificate. DFAT adjusts its fees in line with the Consumer Price Index on 1 January each year. Private documents such as a power of attorney must be notarised first, and the Notary Public charges a separate fee of their own.

### How long does it take to get an apostille in Australia?

DFAT's processing time is usually a few business days, but appointment availability varies by city and can add several weeks, so plan ahead. Lodging by post adds delivery time in both directions. If a Notary Public must sign your document first, or a translation is needed afterwards, build those steps into your timeline as well.

### Does a power of attorney for Italy need an apostille?

A power of attorney is a private document, so for use in Italy it must be signed before an Australian Notary Public and then apostilled by DFAT, because Italy is a member of the Apostille Convention. It also needs an Italian translation certified as conforming to the original. Always confirm the exact requirements with your Italian lawyer or notary before you sign.

### What is the difference between an apostille and an authentication?

Both are DFAT certificates confirming that a signature, stamp or seal on an Australian public document is genuine. An apostille is for countries where the Apostille Convention is in force and needs no further legalisation. An authentication is for all other countries and is usually followed by legalisation at that country's embassy or consulate.

### Can a Justice of the Peace certify my document for an apostille?

No. DFAT only accepts private documents, and copies of documents, once they have been notarised by an Australian Notary Public. A document signed or certified only before a Justice of the Peace is not enough on its own. Original public documents, such as birth, marriage and death certificates, can generally be lodged directly without notarisation.

### Which countries accept an Australian apostille?

Any country where the Apostille Convention is in force. The HCCH lists 130 Contracting Parties (updated 30 June 2026), including Italy, Germany, Spain, the United Kingdom, the United States and New Zealand. Viet Nam has applied the Convention since 11 September 2026, while Thailand follows on 28 February 2027. Check the HCCH status table for your destination.

### Do I need to translate an apostilled document for Italy?

Yes, in most cases. Italy requires foreign documents to be translated into Italian, with the translation certified as conforming to the original, except for multilingual standard forms. Italian notarial guidance notes that the apostille certificate itself does not need translating, because its format is standardised. The Italian Consulate General in Sydney lists the translation routes it accepts.

### How do I check if an Australian apostille is genuine?

Apostilles issued by DFAT on or after 14 December 2015 can be verified online through DFAT's apostille e-Register. For apostilles issued before that date, you can ask an Australian embassy or the Australian Passport Office to verify them. Remember that an apostille only confirms the signature, capacity and seal, not the content of the document itself.

### Can I buy property at an Italian judicial auction from Australia?

Italian law allows bids in person or through an agent holding a special power of attorney, and lawyers can bid for a person to be named and must declare that person's name within three days of the auction. In practice, an Italian lawyer (avvocato) can bid on your behalf. Your power of attorney should be signed before the auction, and ideally apostilled and translated too, because a flawed one can make the offer ineffective.

## Disclaimer

This page provides general information about apostilles and powers of attorney for use in Italy. It is not legal advice. Requirements, fees and processing times can change, and the overseas authority receiving your document decides what it accepts. Please confirm your situation with DFAT, the relevant consulate and a qualified Italian lawyer or notary before acting.

*Last reviewed: September 2026*

[Back to the home page](/)

---

## 3. Links

### Outbound links used in the page copy (15 total, each used once)

| # | Anchor text | URL | Section |
|---|---|---|---|
| 1 | Convention of 5 October 1961 Abolishing the Requirement of Legalisation for Foreign Public Documents | https://www.hcch.net/en/instruments/conventions/full-text/?cid=41 | What is an apostille? |
| 2 | apostilles, authentications and certificates of no impediment to marriage | https://www.dfat.gov.au/about-us/our-services/apostilles-authentications-certificates-of-no-impediment-to-marriage/Pages/apostilles-authentications-and-certificates-of-no-impediment-to-marriage | What is an apostille? |
| 3 | The ABCs of Apostilles | https://assets.hcch.net/docs/6dd54368-bebd-4b10-a078-0a92e5bca40a.pdf | What an apostille does not certify |
| 4 | documents it can and cannot legalise | https://www.smartraveller.gov.au/consular-services/notarial-services/documents | Documents DFAT can apostille |
| 5 | notarial services hub on Smartraveller | https://www.smartraveller.gov.au/consular-services/notarial-services | Step 2: Have private documents notarised by an Australian Notary Public |
| 6 | book an in-person appointment or lodge by post | https://www.smartraveller.gov.au/consular-services/notarial-services/documents-in-australia | Step 3: Lodge your documents with DFAT by appointment or by post |
| 7 | DFAT's apostille e-Register | https://orao.dfat.gov.au/pages/verifyapostille.aspx | Step 6: Check and verify your apostille |
| 8 | Apostille Section | https://www.hcch.net/en/instruments/conventions/specialised-sections/apostille | Step 6: Check and verify your apostille |
| 9 | using Australian documents overseas | https://www.smartraveller.gov.au/consular-services/notarial-services/documents-overseas | Apostille vs authentication |
| 10 | HCCH status table for the Apostille Convention | https://www.hcch.net/en/instruments/conventions/status-table/?cid=41 | Which countries accept apostilles? |
| 11 | translation and legalisation of foreign documents | https://www.esteri.it/en/servizi-opportunita/italiani-all-estero/traduzione-e-legalizzazione-documenti/ | Apostilles for Italy: powers of attorney, property and judicial auctions |
| 12 | notarial services page | https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/servizi-notarili/ | A power of attorney for buying property in Italy |
| 13 | power of attorney service | https://consmelbourne.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/power-of-attorney/ | A power of attorney for buying property in Italy |
| 14 | translating and legalising documents | https://conssydney.esteri.it/en/servizi-consolari-e-visti/servizi-per-il-cittadino-italiano/traduzione-e-legalizzazione-dei-documenti/ | Translation routes accepted for Italy |
| 15 | Portale delle Vendite Pubbliche | https://pvp.giustizia.it/pvp/it/ | Italian judicial auctions (aste giudiziarie) in plain English |

All outbound links should open in the same tab or a new tab at the owner's preference. No `nofollow` is needed on government or HCCH links.

### Internal links (these pages must exist on lunadreyer.com.au before publishing)

| Slug | Anchor text | Section | Status |
|---|---|---|---|
| /power-of-attorney-italy | powers of attorney for Italy | Apostille in Australia: How to Get One, What It Costs and How It Works for Italy | must exist (create if missing) |
| /buying-property-in-italy | buying property in Italy from Australia | Italian judicial auctions (aste giudiziarie) in plain English | must exist (create if missing) |
| /translation-services | translation services | How I can help with your apostille and power of attorney for Italy | must exist (create if missing) |
| /contact | contact page | How I can help with your apostille and power of attorney for Italy | must exist |
| / | Back to the home page | Disclaimer | home page, likely exists |

---

## 4. Images and video

Upload all media to https://lunadreyer.com.au/media/. Compress images to WebP or optimised JPEG (hero under 200 KB), set explicit width and height to avoid layout shift, lazy load everything except the hero, and add `muted playsinline loop` plus a poster image to both videos so they autoplay silently on mobile.

### a) apostille-scan

| Field | Value |
|---|---|
| SEO filename | `apostille-certificate-australia-dfat-example.jpg` |
| Alt text (121 characters) | Australian DFAT apostille certificate in Hague Convention format with ten numbered fields, red seal and DFAT Sydney stamp |
| Title attribute | Example of an Australian DFAT apostille certificate |
| Caption | Example of an Australian apostille certificate issued by DFAT, showing the ten standard fields, seal and stamp. |
| Placement | "What is an apostille" section, under the H3 "What an Australian apostille looks like". Full content width, no crop. Before publishing, blur or redact any personal names, signatures and certificate numbers on the scan. |

### b) apostille-folder (hero)

| Field | Value |
|---|---|
| SEO filename | `apostille-certificate-navy-folder-desk.jpg` |
| Alt text (91 characters) | Apostille certificate for use overseas lying on a navy leather folder on a dark timber desk |
| Title attribute | Apostille certificate on a navy leather folder |
| Caption | An apostille is the certificate that lets an Australian document be used overseas. |
| Placement | Hero, directly under the H1. Load eagerly with fetchpriority="high". Also used as the Open Graph and Article image. |

### c) professional-desk

| Field | Value |
|---|---|
| SEO filename | `translator-reviewing-apostilled-document.jpg` |
| Alt text (96 characters) | Professional woman in a navy blazer reviewing an apostilled document with a red seal at her desk |
| Title attribute | Reviewing an apostilled document before it is sent to Italy |
| Caption | Every document is checked before it moves to the next step. |
| Placement | Top of the "How I can help" section. This is an AI generated stock style image, not Luna: do not caption or describe it as Luna. Consider a small "Illustrative image" credit. |

### d) video-salerno-table

| Field | Value |
|---|---|
| SEO filename | `apostille-certificate-salerno-lunch-table.mp4` |
| Poster / thumbnail | `apostille-certificate-salerno-lunch-table.jpg` (a still frame from the video) |
| Alt text (105 characters) | Apostille certificate on a sunny Mediterranean lunch table with lemons, figs, flowers and a garden behind |
| Title attribute | An apostille and a sunny lunch table in southern Italy |
| Caption | Your paperwork in order, and the Mediterranean table waiting. |
| Placement | "An apostille and a phone call away from Salerno" section, directly under the H2. Portrait 9:16, max width about 360 px on desktop, centred; full width on mobile. Silent, autoplay, muted, loop, playsinline. Use the alt text as aria-label on the video element. |
| VideoObject description | An eight second silent portrait video of an Australian apostille certificate with a red seal, propped up on a sunny outdoor lunch table set with lemons, figs, a flower salad and bright flowers, with a garden in the background. It illustrates how a properly apostilled power of attorney is the first step towards a home in southern Italy such as Salerno. |

### e) video-desk

| Field | Value |
|---|---|
| SEO filename | `apostille-certificate-desk-law-books.mp4` |
| Poster / thumbnail | `apostille-certificate-desk-law-books.jpg` (a still frame from the video) |
| Alt text (101 characters) | Hand resting on an Australian apostille certificate with a red seal on a timber desk beside law books |
| Title attribute | Getting an apostille in Australia, step by step |
| Caption | Getting an apostille in Australia starts with the right document, in the right order. |
| Placement | "How to get an apostille in Australia: step by step" section, directly under the H2 and before step 1. Portrait 9:16, max width about 360 px on desktop (can sit beside the steps in a two column layout), full width on mobile. Silent, autoplay, muted, loop, playsinline. Use the alt text as aria-label. |
| VideoObject description | An eight second silent portrait video of a hand resting on an Australian apostille certificate with a red seal and official stamp, on a dark timber desk with law books, a pen stand and a globe in the background. It introduces the step by step guide to getting a DFAT apostille in Australia. |

---

## 5. JSON-LD structured data

Paste each block into its own `<script type="application/ld+json">` tag in the page head (or combine them in one `@graph`). Replace [PHONE] in the ProfessionalService block before publishing, or remove the telephone line. No review or rating markup is included, by design. Give each step heading an HTML id (step-1 to step-6) so the HowTo step URLs resolve, and keep the visible FAQ wording identical to the FAQPage block if either is edited.

### Article

```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "@id": "https://lunadreyer.com.au/apostille-australia#article",
  "headline": "Apostille in Australia: how to get one, what it costs and how it works across Europe",
  "description": "How to get an apostille in Australia: DFAT steps, the A$105 fee, and apostilled powers of attorney for Italy, Spain, Germany and other European countries.",
  "inLanguage": "en-AU",
  "image": [
    "https://lunadreyer.com.au/media/apostille-certificate-navy-folder-desk.jpg",
    "https://lunadreyer.com.au/media/apostille-certificate-australia-dfat-example.jpg"
  ],
  "datePublished": "2026-09-17",
  "dateModified": "2026-09-17",
  "author": {
    "@type": "Person",
    "@id": "https://lunadreyer.com.au/#luna",
    "name": "Luna Dreyer",
    "url": "https://lunadreyer.com.au/",
    "jobTitle": "Translator",
    "email": "mailto:mail@lunadreyer.com.au",
    "alumniOf": {
      "@type": "CollegeOrUniversity",
      "name": "University of Heidelberg"
    },
    "knowsLanguage": [
      "de",
      "en",
      "es",
      "it",
      "pt"
    ]
  },
  "publisher": {
    "@type": "Organization",
    "@id": "https://lunadreyer.com.au/#organization",
    "name": "Luna Dreyer Translation",
    "url": "https://lunadreyer.com.au/"
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://lunadreyer.com.au/apostille-australia"
  },
  "about": [
    {
      "@type": "Thing",
      "name": "Apostille"
    },
    {
      "@type": "Thing",
      "name": "Power of attorney"
    },
    {
      "@type": "Thing",
      "name": "Italy"
    },
    {
      "@type": "Thing",
      "name": "Spain"
    },
    {
      "@type": "Thing",
      "name": "Germany"
    }
  ],
  "video": [
    {
      "@id": "https://lunadreyer.com.au/apostille-australia#video-desk"
    },
    {
      "@id": "https://lunadreyer.com.au/apostille-australia#video-salerno"
    }
  ]
}
```

### FAQPage

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "@id": "https://lunadreyer.com.au/apostille-australia#faq",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "How much does an apostille cost in Australia?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "From 1 January 2026, DFAT charges A$105 for each apostille, and the same for an authentication certificate. DFAT adjusts its fees in line with the Consumer Price Index on 1 January each year. Private documents such as a power of attorney must be notarised first, and the Notary Public charges a separate fee of their own."
      }
    },
    {
      "@type": "Question",
      "name": "How long does it take to get an apostille in Australia?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "DFAT's processing time is usually a few business days, but appointment availability varies by city and can add several weeks, so plan ahead. Lodging by post adds delivery time in both directions. If a Notary Public must sign your document first, or a translation is needed afterwards, build those steps into your timeline as well."
      }
    },
    {
      "@type": "Question",
      "name": "Does a power of attorney for Italy need an apostille?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "A power of attorney is a private document, so for use in Italy it must be signed before an Australian Notary Public and then apostilled by DFAT, because Italy is a member of the Apostille Convention. It also needs an Italian translation certified as conforming to the original. Always confirm the exact requirements with your Italian lawyer or notary before you sign."
      }
    },
    {
      "@type": "Question",
      "name": "What is the difference between an apostille and an authentication?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Both are DFAT certificates confirming that a signature, stamp or seal on an Australian public document is genuine. An apostille is for countries where the Apostille Convention is in force and needs no further legalisation. An authentication is for all other countries and is usually followed by legalisation at that country's embassy or consulate."
      }
    },
    {
      "@type": "Question",
      "name": "Can a Justice of the Peace certify my document for an apostille?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No. DFAT only accepts private documents, and copies of documents, once they have been notarised by an Australian Notary Public. A document signed or certified only before a Justice of the Peace is not enough on its own. Original public documents, such as birth, marriage and death certificates, can generally be lodged directly without notarisation."
      }
    },
    {
      "@type": "Question",
      "name": "Which countries accept an Australian apostille?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Any country where the Apostille Convention is in force. The HCCH lists 130 Contracting Parties (updated 30 June 2026), including Italy, Germany, Spain, the United Kingdom, the United States and New Zealand. Viet Nam has applied the Convention since 11 September 2026, while Thailand follows on 28 February 2027. Check the HCCH status table for your destination."
      }
    },
    {
      "@type": "Question",
      "name": "Do I need to translate an apostilled document for Italy?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, in most cases. Italy requires foreign documents to be translated into Italian, with the translation certified as conforming to the original, except for multilingual standard forms. Italian notarial guidance notes that the apostille certificate itself does not need translating, because its format is standardised. The Italian Consulate General in Sydney lists the translation routes it accepts."
      }
    },
    {
      "@type": "Question",
      "name": "How do I check if an Australian apostille is genuine?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Apostilles issued by DFAT on or after 14 December 2015 can be verified online through DFAT's apostille e-Register. For apostilles issued before that date, you can ask an Australian embassy or the Australian Passport Office to verify them. Remember that an apostille only confirms the signature, capacity and seal, not the content of the document itself."
      }
    },
    {
      "@type": "Question",
      "name": "Do you only help with Italy, or other European countries too?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "I also help with Spain and Germany, not only Italy, and I am not limited to any single European language. The apostille process itself is the same wherever the document is going: what changes between countries is the translation and the local lawyer or notary requirements, which I confirm before anything is signed."
      }
    },
    {
      "@type": "Question",
      "name": "Can I buy property at an Italian judicial auction from Australia?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Italian law allows bids in person or through an agent holding a special power of attorney, and lawyers can bid for a person to be named and must declare that person's name within three days of the auction. In practice, an Italian lawyer (avvocato) can bid on your behalf. Your power of attorney should be signed before the auction, and ideally apostilled and translated too, because a flawed one can make the offer ineffective."
      }
    }
  ]
}
```

### HowTo

```json
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "@id": "https://lunadreyer.com.au/apostille-australia#howto",
  "name": "How to get an apostille in Australia",
  "inLanguage": "en-AU",
  "description": "Step by step process for getting a DFAT apostille on an Australian document for use overseas.",
  "image": "https://lunadreyer.com.au/media/apostille-certificate-navy-folder-desk.jpg",
  "estimatedCost": {
    "@type": "MonetaryAmount",
    "currency": "AUD",
    "value": "105"
  },
  "supply": [
    {
      "@type": "HowToSupply",
      "name": "Original public document or notarised private document"
    },
    {
      "@type": "HowToSupply",
      "name": "DFAT Document Legalisation Request Form"
    }
  ],
  "video": {
    "@id": "https://lunadreyer.com.au/apostille-australia#video-desk"
  },
  "step": [
    {
      "@type": "HowToStep",
      "position": 1,
      "name": "Check what the destination country requires",
      "text": "Confirm whether the Apostille Convention is in force in the destination country. If it is, request an apostille; if not, request an authentication followed by embassy or consulate legalisation. Ask the receiving authority whether a translation is also required.",
      "url": "https://lunadreyer.com.au/apostille-australia#step-1"
    },
    {
      "@type": "HowToStep",
      "position": 2,
      "name": "Have private documents notarised by an Australian Notary Public",
      "text": "Private documents such as a power of attorney, will, bank statements or company documents, and any copies, must be notarised by an Australian Notary Public before lodgement. Original public documents such as birth, marriage and death certificates can generally be lodged directly.",
      "url": "https://lunadreyer.com.au/apostille-australia#step-2"
    },
    {
      "@type": "HowToStep",
      "position": 3,
      "name": "Lodge your documents with DFAT by appointment or by post",
      "text": "Book an in-person appointment at an Australian Passport Office through Smartraveller, or lodge by post using DFAT's current Document Legalisation Request Form.",
      "url": "https://lunadreyer.com.au/apostille-australia#step-3"
    },
    {
      "@type": "HowToStep",
      "position": 4,
      "name": "Pay the DFAT fee",
      "text": "Pay A$105 per apostille or authentication (fee from 1 January 2026, adjusted each 1 January in line with CPI).",
      "url": "https://lunadreyer.com.au/apostille-australia#step-4"
    },
    {
      "@type": "HowToStep",
      "position": 5,
      "name": "Allow enough time",
      "text": "Processing is usually a few business days, but appointment availability varies by city and can add several weeks. Postal lodgement adds delivery time in both directions.",
      "url": "https://lunadreyer.com.au/apostille-australia#step-5"
    },
    {
      "@type": "HowToStep",
      "position": 6,
      "name": "Check and verify your apostille",
      "text": "Check the returned certificate and verify apostilles issued on or after 14 December 2015 on DFAT's online e-Register. Older apostilles can be verified through an Australian embassy or the Australian Passport Office.",
      "url": "https://lunadreyer.com.au/apostille-australia#step-6"
    }
  ]
}
```

### BreadcrumbList

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://lunadreyer.com.au/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Apostille in Australia",
      "item": "https://lunadreyer.com.au/apostille-australia"
    }
  ]
}
```

### ProfessionalService

```json
{
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  "@id": "https://lunadreyer.com.au/#service",
  "name": "Luna Dreyer Translation",
  "url": "https://lunadreyer.com.au/",
  "email": "mail@lunadreyer.com.au",
  "telephone": "[PHONE]",
  "image": "https://lunadreyer.com.au/media/apostille-certificate-navy-folder-desk.jpg",
  "description": "Translator helping Australians prepare powers of attorney with apostilles for Italy, Spain, Germany and other European countries: bilingual document preparation, coordinating the Notary Public and DFAT apostille, arranging translation through her own languages or her network of European translators, and introductions to trusted local lawyers.",
  "areaServed": {
    "@type": "Country",
    "name": "Australia"
  },
  "knowsLanguage": [
    "de",
    "en",
    "es",
    "it",
    "pt"
  ],
  "founder": {
    "@id": "https://lunadreyer.com.au/#luna"
  },
  "serviceType": [
    "Bilingual power of attorney preparation for Europe",
    "Apostille coordination",
    "Translation services"
  ]
}
```

### VideoObject (apostille-certificate-desk-law-books.mp4)

```json
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "@id": "https://lunadreyer.com.au/apostille-australia#video-desk",
  "name": "How to get an apostille in Australia",
  "description": "An eight second silent portrait video of a hand resting on an Australian apostille certificate with a red seal and official stamp, on a dark timber desk with law books, a pen stand and a globe in the background. It introduces the step by step guide to getting a DFAT apostille in Australia.",
  "thumbnailUrl": "https://lunadreyer.com.au/media/apostille-certificate-desk-law-books.jpg",
  "contentUrl": "https://lunadreyer.com.au/media/apostille-certificate-desk-law-books.mp4",
  "uploadDate": "2026-09-17",
  "duration": "PT8S",
  "inLanguage": "en-AU",
  "isFamilyFriendly": true,
  "publisher": {
    "@type": "Organization",
    "@id": "https://lunadreyer.com.au/#organization",
    "name": "Luna Dreyer Translation",
    "url": "https://lunadreyer.com.au/"
  }
}
```

### VideoObject (apostille-certificate-salerno-lunch-table.mp4)

```json
{
  "@context": "https://schema.org",
  "@type": "VideoObject",
  "@id": "https://lunadreyer.com.au/apostille-australia#video-salerno",
  "name": "Apostille certificate on a Mediterranean lunch table",
  "description": "An eight second silent portrait video of an Australian apostille certificate with a red seal, propped up on a sunny outdoor lunch table set with lemons, figs, a flower salad and bright flowers, with a garden in the background. It illustrates how a properly apostilled power of attorney is the first step towards a home in southern Italy such as Salerno.",
  "thumbnailUrl": "https://lunadreyer.com.au/media/apostille-certificate-salerno-lunch-table.jpg",
  "contentUrl": "https://lunadreyer.com.au/media/apostille-certificate-salerno-lunch-table.mp4",
  "uploadDate": "2026-09-17",
  "duration": "PT8S",
  "inLanguage": "en-AU",
  "isFamilyFriendly": true,
  "publisher": {
    "@type": "Organization",
    "@id": "https://lunadreyer.com.au/#organization",
    "name": "Luna Dreyer Translation",
    "url": "https://lunadreyer.com.au/"
  }
}
```

---

## 6. Backlink plan

True backlinks come from other websites, so these are targets for Luna to pursue over the next few months. Nothing in this list was verified live during this session unless marked "known"; anything marked "check" should be confirmed (that it exists, that it still accepts listings, and its membership rules) before you approach it.

| # | Target | Type | Why it helps | Pitch angle | Status |
|---|---|---|---|---|---|
| 1 | Google Business Profile | Local profile | Strongest local signal for "apostille" and "translator" searches, and a link to the page | Set up as a service area business (Australia wide), category Translator, add this page as a service link and post updates when DFAT fees change each January | known |
| 2 | Bing Places for Business | Local profile | Feeds Bing, Copilot and several map apps | Mirror the Google Business Profile details exactly (same name, email, phone) | known |
| 3 | Apple Business Connect | Local profile | Visibility in Apple Maps and Siri results on iPhone | Same details as Google, link to this page | known |
| 4 | AUSIT (Australian Institute of Interpreters and Translators) member directory | Translator association | Relevant, trusted industry link | Join as a member if eligible and list German, Spanish, Italian and Portuguese with a link to the site | check (membership criteria) |
| 5 | ProZ.com and TranslatorsCafe profiles | Translator directories | Relevant profile links and client enquiries | Complete profiles naming power of attorney and apostille coordination for Italy | check |
| 6 | Italian Chamber of Commerce and Industry in Australia (state chambers) | Business association | Authoritative Italian Australian business link through member directories | Join and offer a short member briefing on preparing documents for Italian property purchases | check |
| 7 | Co.As.It. (Italian community organisations in Melbourne and Sydney) | Community organisation | Trusted by Italian Australian families dealing with citizenship and inheritance paperwork | Offer a free community information session on apostilles and powers of attorney for Italy | check |
| 8 | COMITES (Committees of Italians Abroad) in Australia | Community body | Reaches Italian citizens in Australia who need documents for Italy | Offer a plain English explainer on the apostille and translation steps for their newsletter or website | check |
| 9 | SBS Italian | Broadcaster | High authority media link and direct reach to the Italian speaking community | Pitch an interview on the Italian Code rules for bidding at judicial auctions from Australia, or on apostille timing | known (pitch contact: check) |
| 10 | Il Globo and other Italian Australian publications | Community media | Relevant audience, possible article link | Guest article: "Eleven weeks for one document", your story plus a checklist | check (current publication status) |
| 11 | Dante Alighieri Society branches in Australia | Language and culture | Local branch websites and newsletters reach Italian learners planning time in Italy | Offer a talk or newsletter piece on buying a home in Italy from Australia | check |
| 12 | Istituto Italiano di Cultura (Sydney and Melbourne) | Cultural institute | Authoritative Italian institutional audience | Propose an event or resource listing on practical steps for moving to or buying in Italy | check |
| 13 | Heidelberg University alumni network | Alumni directory | Education link that supports your expertise signals | Create an alumni profile linking to the site | check |
| 14 | Yellow (Yellow Pages Australia), True Local, Hotfrog, StartLocal | Local citation sites | Consistent name, email and phone across citations supports local ranking | List under Translators, using identical details and this page URL | check |
| 15 | Expat and Italy property communities (for example Italy focused expat directories and forums) | Expat directories | Readers actively planning a purchase in Italy | Offer a practical guide on the power of attorney and apostille sequence for buyers in Australia | check (choose specific sites) |

Tips: keep name, email and phone identical everywhere (NAP consistency), update listings once [PHONE] is set, and refresh the fee and country figures on this page each January so it stays the most current source worth linking to.
